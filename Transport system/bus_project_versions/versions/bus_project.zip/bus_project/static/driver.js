var map=L.map('map').setView([17.385,78.486],13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
maxZoom:19
}).addTo(map);

var marker=L.marker([17.385,78.486]).addTo(map);
var routeLine=L.polyline([],{color:"red"}).addTo(map);

var socket=io();

socket.on("route_update",function(data){
routeLine.setLatLngs(data);
});

socket.on("bus_location",function(data){
marker.setLatLng([data.lat,data.lon]);
});

function setDestination(){

var lat=document.getElementById("lat").value;
var lon=document.getElementById("lon").value;

fetch("/set_destination",{

method:"POST",
headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({
lat:parseFloat(lat),
lon:parseFloat(lon)
})

});

}

setInterval(function(){

navigator.geolocation.getCurrentPosition(function(pos){

fetch("/gps",{

method:"POST",
headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

lat:pos.coords.latitude,
lon:pos.coords.longitude,
speed:pos.coords.speed || 0

})

});

});

},3000);