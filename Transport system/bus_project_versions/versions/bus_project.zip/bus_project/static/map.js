var map = L.map('map').setView([17.385,78.486],13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
maxZoom:19
}).addTo(map);

var marker=L.marker([17.385,78.486]).addTo(map);
var routeLine=L.polyline([],{color:"blue"}).addTo(map);

var socket=io();

socket.on("passenger_update",function(data){
document.getElementById("count").innerHTML=data;
});

socket.on("bus_location",function(data){
marker.setLatLng([data.lat,data.lon]);
});

socket.on("route_update",function(data){
routeLine.setLatLngs(data);
});