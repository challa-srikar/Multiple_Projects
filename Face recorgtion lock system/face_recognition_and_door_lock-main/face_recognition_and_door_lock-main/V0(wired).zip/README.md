# face_recognition_and_door_lock

# install Python 3.10
# pip install opencv-python
# pip install pillow
# pip uninstall opencv-python -y
# pip install opencv-contrib-python
# pip install pyfirmata
# press "O" on keyboard to unlock
# press "q" on keyboard to exit the software